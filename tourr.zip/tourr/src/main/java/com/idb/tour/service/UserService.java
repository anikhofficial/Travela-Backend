package com.idb.tour.service;

import java.util.List;

import com.idb.tour.model.User;

public interface UserService {
    User getUserById(Long id);
    List<User> getAllUsers();
    User saveUser(User user);
    void deleteUser(Long id);
}

