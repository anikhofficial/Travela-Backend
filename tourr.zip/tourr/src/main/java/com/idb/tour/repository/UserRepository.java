package com.idb.tour.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.idb.tour.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    // Additional query methods if needed
}
